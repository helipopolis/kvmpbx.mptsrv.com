<?php
  $host = 'localhost'; // адрес сервера 
  $database = 'asterisk'; // имя базы данных
  $user = 'asterisk'; // имя пользователя
  $password = 'asterisk'; // пароль
?>
