    <?php echo date("H:i:s"); ?>  
